from view import View
from controller import Controller
from UserDAO import UserDAO
from InstitutionDAO import InstitutionDAO
from ColaboradorDAO import ColaboradorDAO
from ComprometidoDAO import ComprometidoDAO
from StudentDAO import StudentDAO
from EnrollmentDAO import EnrollmentDAO


def main():
    database = 'database.db'
    view = View()
    user_dao = UserDAO(database)
    institution_dao = InstitutionDAO(database)
    colaborador_dao = ColaboradorDAO(database)
    comprometido_dao = ComprometidoDAO(database)
    student_dao = StudentDAO(database)
    enrollment_dao = EnrollmentDAO(database)

    controller = Controller(view, user_dao, institution_dao, colaborador_dao, comprometido_dao, student_dao, enrollment_dao)

    while True:
        opcion = view.menu_principal()
        if opcion == '1':
            controller.ingresar_datos()
        elif opcion == '2':
            controller.ver_datos()
        elif opcion == '0':
            break


if __name__ == "__main__":
    main()
