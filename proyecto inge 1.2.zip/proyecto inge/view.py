class View:
    def menu_principal(self):
        print("Menú Principal")
        print("1. Ingresar datos")
        print("2. Consultar todos los datos")
        print("0. Salir")
        return input("Seleccione una opción: ")

    def menu_ingresar_datos(self):
        print("Menú Ingresar Datos")
        print("1. Registrar Usuario")
        print("2. Registrar Institución")
        print("3. Registrar Colaborador")
        print("4. Registrar Comprometido")
        print("5. Registrar Estudiante")
        print("6. Inscribir Evento")
        return input("Seleccione una opción: ")

    # Métodos para obtener datos de entrada y mostrar datos (como en la versión anterior)
