class InstitutionDTO:
    def __init__(self, name, address):
        self.name = name
        self.address = address
