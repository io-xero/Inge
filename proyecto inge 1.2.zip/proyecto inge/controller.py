from UserDTO import UserDTO
from InstitutionDTO import InstitutionDTO
from ColaboradorDTO import ColaboradorDTO
from ComprometidoDTO import ComprometidoDTO
from StudentDTO import StudentDTO
from EnrollmentDTO import EnrollmentDTO

from UserDAO import UserDAO
from InstitutionDAO import InstitutionDAO
from ColaboradorDAO import ColaboradorDAO
from ComprometidoDAO import ComprometidoDAO
from StudentDAO import StudentDAO
from EnrollmentDAO import EnrollmentDAO

class Controller:
    def __init__(self, view, user_dao, institution_dao, colaborador_dao, comprometido_dao, student_dao, enrollment_dao):
        self.view = view
        self.user_dao = user_dao
        self.institution_dao = institution_dao
        self.colaborador_dao = colaborador_dao
        self.comprometido_dao = comprometido_dao
        self.student_dao = student_dao
        self.enrollment_dao = enrollment_dao

    def ingresar_datos(self):
        opcion = self.view.menu_ingresar_datos()
        if opcion == '1':
            self.registrar_usuario()
        elif opcion == '2':
            self.registrar_institucion()
        elif opcion == '3':
            self.registrar_colaborador()
        elif opcion == '4':
            self.registrar_comprometido()
        elif opcion == '5':
            self.registrar_estudiante()
        elif opcion == '6':
            self.inscribir_evento()

    def ver_datos(self):
        self.ver_usuario()
        self.ver_institucion()
        self.ver_colaborador()
        self.ver_comprometido()
        self.ver_estudiante()
        self.ver_inscripcion()

    def ver_usuario(self):
        print("Mostrando datos del usuario")
        # código para mostrar los datos del usuario

    def ver_institucion(self):
        print("Mostrando datos de la institución")
        # código para mostrar los datos de la institución

    def ver_colaborador(self):
        print("Mostrando datos del colaborador")
        # código para mostrar los datos del colaborador

    def ver_comprometido(self):
        print("Mostrando datos del comprometido")
        # código para mostrar los datos del comprometido

    def ver_estudiante(self):
        print("Mostrando datos del estudiante")
        # código para mostrar los datos del estudiante

    def ver_inscripcion(self):
        print("Mostrando datos de la inscripción")
        # código para mostrar los datos de la inscripción

    # Métodos para registrar entidades
    def registrar_usuario(self):
        print("Registrando usuario")
        # código para registrar usuario

    def registrar_institucion(self):
        print("Registrando institución")
        # código para registrar institución

    def registrar_colaborador(self):
        print("Registrando colaborador")
        # código para registrar colaborador

    def registrar_comprometido(self):
        print("Registrando comprometido")
        # código para registrar comprometido

    def registrar_estudiante(self):
        print("Registrando estudiante")
        # código para registrar estudiante

    def inscribir_evento(self):
        print("Inscribiendo evento")
        # código para inscribir evento
