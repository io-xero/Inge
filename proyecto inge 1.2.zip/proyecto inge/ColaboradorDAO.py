# ColaboradorDAO.py
import sqlite3

class ColaboradorDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS colaboradores
                               (username TEXT PRIMARY KEY, password TEXT)''')
        self.conn.commit()

    def add_colaborador(self, colaborador_dto):
        self.cursor.execute('INSERT INTO colaboradores (username, password) VALUES (?, ?)', (colaborador_dto.username, colaborador_dto.password))
        self.conn.commit()

    def get_colaborador(self, username):
        self.cursor.execute('SELECT username, password FROM colaboradores WHERE username = ?', (username,))
        return self.cursor.fetchone()
