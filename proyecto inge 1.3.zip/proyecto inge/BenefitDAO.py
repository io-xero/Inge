# BenefitDAO.py
import sqlite3

class BenefitDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS benefits
                               (name TEXT PRIMARY KEY, description TEXT)''')
        self.conn.commit()

    def add_benefit(self, benefit_dto):
        self.cursor.execute('INSERT INTO benefits (name, description) VALUES (?, ?)', (benefit_dto.name, benefit_dto.description))
        self.conn.commit()

    def get_benefit(self, name):
        self.cursor.execute('SELECT name, description FROM benefits WHERE name = ?', (name,))
        return self.cursor.fetchone()
