import sqlite3

class UserDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS users
                               (username TEXT PRIMARY KEY, password TEXT)''')
        self.conn.commit()

    def add_user(self, user_dto):
        self.cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (user_dto.username, user_dto.password))
        self.conn.commit()

    def get_user(self, username):
        self.cursor.execute('SELECT username, password FROM users WHERE username = ?', (username,))
        return self.cursor.fetchone()
