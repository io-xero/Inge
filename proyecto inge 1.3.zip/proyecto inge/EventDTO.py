class EventDTO:
    def __init__(self, title, description, date):
        self.title = title
        self.description = description
        self.date = date
