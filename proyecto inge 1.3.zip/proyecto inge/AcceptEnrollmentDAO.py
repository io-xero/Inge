# AcceptEnrollmentDAO.py
import sqlite3

class AcceptEnrollmentDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS accepted_enrollments
                               (event_id INTEGER, username TEXT, PRIMARY KEY (event_id, username))''')
        self.conn.commit()

    def add_accepted_enrollment(self, accept_enrollment_dto):
        self.cursor.execute('INSERT INTO accepted_enrollments (event_id, username) VALUES (?, ?)', (accept_enrollment_dto.event_id, accept_enrollment_dto.username))
        self.conn.commit()

    def get_accepted_enrollment(self, event_id, username):
        self.cursor.execute('SELECT event_id, username FROM accepted_enrollments WHERE event_id = ? AND username = ?', (event_id, username))
        return self.cursor.fetchone()
