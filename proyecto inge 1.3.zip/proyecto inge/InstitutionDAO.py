# InstitutionDAO.py
import sqlite3

class InstitutionDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS institutions
                               (name TEXT PRIMARY KEY, address TEXT)''')
        self.conn.commit()

    def add_institution(self, institution_dto):
        self.cursor.execute('INSERT INTO institutions (name, address) VALUES (?, ?)', (institution_dto.name, institution_dto.address))
        self.conn.commit()

    def get_institution(self, name):
        self.cursor.execute('SELECT name, address FROM institutions WHERE name = ?', (name,))
        return self.cursor.fetchone()
