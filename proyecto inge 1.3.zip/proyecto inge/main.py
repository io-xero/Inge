# main.py
from view import View
from controller import Controller
from UserDAO import UserDAO
from InstitutionDAO import InstitutionDAO
from ColaboradorDAO import ColaboradorDAO
from ComprometidoDAO import ComprometidoDAO
from BenefitDAO import BenefitDAO
from EventDAO import EventDAO
from StudentDAO import StudentDAO
from PublishEventDAO import PublishEventDAO
from EnrollmentDAO import EnrollmentDAO
from AcceptEnrollmentDAO import AcceptEnrollmentDAO
from CheckEnrollmentDAO import CheckEnrollmentDAO
 
def main():
    database = 'database.db'
    view = View()
    user_dao = UserDAO(database)
    institution_dao = InstitutionDAO(database)
    colaborador_dao = ColaboradorDAO(database)
    comprometido_dao = ComprometidoDAO(database)
    benefit_dao = BenefitDAO(database)
    event_dao = EventDAO(database)
    student_dao = StudentDAO(database)
    publish_event_dao = PublishEventDAO(database)
    enrollment_dao = EnrollmentDAO(database)
    accept_enrollment_dao = AcceptEnrollmentDAO(database)
    check_enrollment_dao = CheckEnrollmentDAO(database)

    controller = Controller(view, user_dao, institution_dao, colaborador_dao, comprometido_dao, benefit_dao, event_dao,
                            student_dao, publish_event_dao, enrollment_dao, accept_enrollment_dao, check_enrollment_dao)

    while True:
        opcion = view.menu_principal()
        if opcion == '1':
            controller.registrar_usuario()
        elif opcion == '2':
            controller.ver_usuario()
        elif opcion == '3':
            controller.registrar_institucion()
        elif opcion == '4':
            controller.ver_institucion()
        elif opcion == '5':
            controller.registrar_colaborador()
        elif opcion == '6':
            controller.ver_colaborador()
        elif opcion == '7':
            controller.registrar_comprometido()
        elif opcion == '8':
            controller.ver_comprometido()
        elif opcion == '9':
            controller.registrar_beneficio()
        elif opcion == '10':
            controller.ver_beneficio()
        elif opcion == '11':
            controller.registrar_evento()
        elif opcion == '12':
            controller.ver_evento()
        elif opcion == '13':
            controller.registrar_estudiante()
        elif opcion == '14':
            controller.ver_estudiante()
        elif opcion == '0':
            break


if __name__ == "__main__":
    main()