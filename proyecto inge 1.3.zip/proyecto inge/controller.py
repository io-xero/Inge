# controller.py
from UserDTO import UserDTO
from InstitutionDTO import InstitutionDTO
from ColaboradorDTO import ColaboradorDTO
from ComprometidoDTO import ComprometidoDTO
from BenefitDTO import BenefitDTO
from EventDTO import EventDTO
from StudentDTO import StudentDTO
from PublishEventDTO import PublishEventDTO
from EnrollmentDTO import EnrollmentDTO
from AcceptEnrollmentDTO import AcceptEnrollmentDTO
from CheckEnrollmentDTO import CheckEnrollmentDTO

from UserDAO import UserDAO
from InstitutionDAO import InstitutionDAO
from ColaboradorDAO import ColaboradorDAO
from ComprometidoDAO import ComprometidoDAO
from BenefitDAO import BenefitDAO
from EventDAO import EventDAO
from StudentDAO import StudentDAO
from PublishEventDAO import PublishEventDAO
from EnrollmentDAO import EnrollmentDAO
from AcceptEnrollmentDAO import AcceptEnrollmentDAO
from CheckEnrollmentDAO import CheckEnrollmentDAO

class Controller:
    def __init__(self, view, user_dao, institution_dao, colaborador_dao, comprometido_dao, benefit_dao, event_dao, student_dao, publish_event_dao, enrollment_dao, accept_enrollment_dao, check_enrollment_dao):
        self.view = view
        self.user_dao = user_dao
        self.institution_dao = institution_dao
        self.colaborador_dao = colaborador_dao
        self.comprometido_dao = comprometido_dao
        self.benefit_dao = benefit_dao
        self.event_dao = event_dao
        self.student_dao = student_dao
        self.publish_event_dao = publish_event_dao
        self.enrollment_dao = enrollment_dao
        self.accept_enrollment_dao = accept_enrollment_dao
        self.check_enrollment_dao = check_enrollment_dao

    def registrar_usuario(self):
        username, password = self.view.obtener_datos_usuario()
        user_dto = UserDTO(username, password)
        self.user_dao.add_user(user_dto)

    def ver_usuario(self):
        username = input("Ingrese nombre de usuario: ")
        usuario = self.user_dao.get_user(username)
        self.view.mostrar_usuario(usuario)

    def registrar_institucion(self):
        name, address = self.view.obtener_datos_institucion()
        institution_dto = InstitutionDTO(name, address)
        self.institution_dao.add_institution(institution_dto)

    def ver_institucion(self):
        name = input("Ingrese nombre de la institución: ")
        institucion = self.institution_dao.get_institution(name)
        self.view.mostrar_institucion(institucion)

    def registrar_colaborador(self):
        username, password = self.view.obtener_datos_colaborador()
        colaborador_dto = ColaboradorDTO(username, password)
        self.colaborador_dao.add_colaborador(colaborador_dto)

    def ver_colaborador(self):
        username = input("Ingrese nombre de usuario: ")
        colaborador = self.colaborador_dao.get_colaborador(username)
        self.view.mostrar_colaborador(colaborador)

    def registrar_comprometido(self):
        username, password = self.view.obtener_datos_comprometido()
        comprometido_dto = ComprometidoDTO(username, password)
        self.comprometido_dao.add_comprometido(comprometido_dto)

    def ver_comprometido(self):
        username = input("Ingrese nombre de usuario: ")
        comprometido = self.comprometido_dao.get_comprometido(username)
        self.view.mostrar_comprometido(comprometido)

    def registrar_beneficio(self):
        name, description = self.view.obtener_datos_beneficio()
        benefit_dto = BenefitDTO(name, description)
        self.benefit_dao.add_benefit(benefit_dto)

    def ver_beneficio(self):
        name = input("Ingrese nombre del beneficio: ")
        beneficio = self.benefit_dao.get_benefit(name)
        self.view.mostrar_beneficio(beneficio)

    def registrar_evento(self):
        title, description, date = self.view.obtener_datos_evento()
        event_dto = EventDTO(title, description, date)
        self.event_dao.add_event(event_dto)

    def ver_evento(self):
        event_id = self.view.obtener_id_evento()
        evento = self.event_dao.get_event(event_id)
        self.view.mostrar_evento(evento)

    def registrar_estudiante(self):
        username, password = self.view.obtener_datos_estudiante()
        student_dto = StudentDTO(username, password)
        self.student_dao.add_student(student_dto)

    def ver_estudiante(self):
        username = input("Ingrese nombre de usuario: ")
        estudiante = self.student_dao.get_student(username)
        self.view.mostrar_estudiante(estudiante)

    def publicar_evento(self):
        event_id = self.view.obtener_id_evento()
        publish_event_dto = PublishEventDTO(event_id)
        self.publish_event_dao.add_publish_event(publish_event_dto)

    def ver_publicacion(self):
        event_id = self.view.obtener_id_evento()
        publicacion = self.publish_event_dao.get_publish_event(event_id)
        self.view.mostrar_evento(publicacion)

    def inscribir_evento(self):
        event_id, username = self.view.obtener_datos_inscripcion()
        enrollment_dto = EnrollmentDTO(event_id, username)
        self.enrollment_dao.add_enrollment(enrollment_dto)

    def ver_inscripcion(self):
        event_id, username = self.view.obtener_datos_inscripcion()
        inscripcion = self.enrollment_dao.get_enrollment(event_id, username)
        self.view.mostrar_inscripcion(inscripcion)

    def aceptar_inscripcion(self):
        event_id, username = self.view.obtener_datos_inscripcion()
        accept_enrollment_dto = AcceptEnrollmentDTO(event_id, username)
        self.accept_enrollment_dao.add_accept_enrollment(accept_enrollment_dto)

    def ver_aceptacion(self):
        event_id, username = self.view.obtener_datos_inscripcion()
        aceptacion = self.accept_enrollment_dao.get_accept_enrollment(event_id, username)
        self.view.mostrar_inscripcion(aceptacion)

    def verificar_inscripcion(self):
        event_id, username = self.view.obtener_datos_inscripcion()
        check_enrollment_dto = CheckEnrollmentDTO(event_id, username)
        self.check_enrollment_dao.add_check_enrollment(check_enrollment_dto)

    def ver_verificacion(self):
        event_id, username = self.view.obtener_datos_inscripcion()
        verificacion = self.check_enrollment_dao.get_check_enrollment(event_id, username)
        self.view.mostrar_inscripcion(verificacion)
