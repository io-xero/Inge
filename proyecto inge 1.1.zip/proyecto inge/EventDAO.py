# EventDAO.py
import sqlite3

class EventDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS events
                               (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, date TEXT)''')
        self.conn.commit()

    def add_event(self, event_dto):
        self.cursor.execute('INSERT INTO events (title, description, date) VALUES (?, ?, ?)', (event_dto.title, event_dto.description, event_dto.date))
        self.conn.commit()

    def get_event(self, event_id):
        self.cursor.execute('SELECT id, title, description, date FROM events WHERE id = ?', (event_id,))
        return self.cursor.fetchone()
