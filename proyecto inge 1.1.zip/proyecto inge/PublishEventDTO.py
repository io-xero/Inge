class PublishEventDTO:
    def __init__(self, event_id):
        self.event_id = event_id
