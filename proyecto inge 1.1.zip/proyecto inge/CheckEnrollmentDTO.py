class CheckEnrollmentDTO:
    def __init__(self, event_id, username):
        self.event_id = event_id
        self.username = username
