# CheckEnrollmentDAO.py
import sqlite3

class CheckEnrollmentDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS checked_enrollments
                               (event_id INTEGER, username TEXT, PRIMARY KEY (event_id, username))''')
        self.conn.commit()

    def add_checked_enrollment(self, check_enrollment_dto):
        self.cursor.execute('INSERT INTO checked_enrollments (event_id, username) VALUES (?, ?)', (check_enrollment_dto.event_id, check_enrollment_dto.username))
        self.conn.commit()

    def get_checked_enrollment(self, event_id, username):
        self.cursor.execute('SELECT event_id, username FROM checked_enrollments WHERE event_id = ? AND username = ?', (event_id, username))
        return self.cursor.fetchone()
