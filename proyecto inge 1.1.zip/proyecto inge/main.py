# main.py
from view import View
from controller import Controller
from UserDAO import UserDAO
from InstitutionDAO import InstitutionDAO
from ColaboradorDAO import ColaboradorDAO
from ComprometidoDAO import ComprometidoDAO
from BenefitDAO import BenefitDAO
from EventDAO import EventDAO
from StudentDAO import StudentDAO
from PublishEventDAO import PublishEventDAO
from EnrollmentDAO import EnrollmentDAO
from AcceptEnrollmentDAO import AcceptEnrollmentDAO
from CheckEnrollmentDAO import CheckEnrollmentDAO


def main():
    database = 'database.db'
    view = View()
    user_dao = UserDAO(database)
    institution_dao = InstitutionDAO(database)
    colaborador_dao = ColaboradorDAO(database)
    comprometido_dao = ComprometidoDAO(database)
    benefit_dao = BenefitDAO(database)
    event_dao = EventDAO(database)
    student_dao = StudentDAO(database)
    publish_event_dao = PublishEventDAO(database)
    enrollment_dao = EnrollmentDAO(database)
    accept_enrollment_dao = AcceptEnrollmentDAO(database)
    check_enrollment_dao = CheckEnrollmentDAO(database)

    controller = Controller(view, user_dao, institution_dao, colaborador_dao, comprometido_dao, benefit_dao, event_dao,
                            student_dao, publish_event_dao, enrollment_dao, accept_enrollment_dao, check_enrollment_dao)

    while True:
        opcion = view.menu_principal()
        if opcion == '1':
            controller.ingresar_datos()
        elif opcion == '2':
            controller.ver_datos()
        elif opcion == '0':
            break


if __name__ == "__main__":
    main()
