from UserDTO import UserDTO
from InstitutionDTO import InstitutionDTO
from ColaboradorDTO import ColaboradorDTO
from ComprometidoDTO import ComprometidoDTO
from BenefitDTO import BenefitDTO
from EventDTO import EventDTO
from StudentDTO import StudentDTO
from PublishEventDTO import PublishEventDTO
from EnrollmentDTO import EnrollmentDTO
from AcceptEnrollmentDTO import AcceptEnrollmentDTO
from CheckEnrollmentDTO import CheckEnrollmentDTO

from UserDAO import UserDAO
from InstitutionDAO import InstitutionDAO
from ColaboradorDAO import ColaboradorDAO
from ComprometidoDAO import ComprometidoDAO
from BenefitDAO import BenefitDAO
from EventDAO import EventDAO
from StudentDAO import StudentDAO
from PublishEventDAO import PublishEventDAO
from EnrollmentDAO import EnrollmentDAO
from AcceptEnrollmentDAO import AcceptEnrollmentDAO
from CheckEnrollmentDAO import CheckEnrollmentDAO

class Controller:
    def __init__(self, view, user_dao, institution_dao, colaborador_dao, comprometido_dao, benefit_dao, event_dao, student_dao, publish_event_dao, enrollment_dao, accept_enrollment_dao, check_enrollment_dao):
        self.view = view
        self.user_dao = user_dao
        self.institution_dao = institution_dao
        self.colaborador_dao = colaborador_dao
        self.comprometido_dao = comprometido_dao
        self.benefit_dao = benefit_dao
        self.event_dao = event_dao
        self.student_dao = student_dao
        self.publish_event_dao = publish_event_dao
        self.enrollment_dao = enrollment_dao
        self.accept_enrollment_dao = accept_enrollment_dao
        self.check_enrollment_dao = check_enrollment_dao

    def ingresar_datos(self):
        opcion = self.view.menu_ingresar_datos()
        if opcion == '1':
            self.registrar_usuario()
        elif opcion == '2':
            self.registrar_institucion()
        elif opcion == '3':
            self.registrar_colaborador()
        elif opcion == '4':
            self.registrar_comprometido()
        elif opcion == '5':
            self.registrar_beneficio()
        elif opcion == '6':
            self.registrar_evento()
        elif opcion == '7':
            self.registrar_estudiante()
        elif opcion == '8':
            self.publicar_evento()
        elif opcion == '9':
            self.inscribir_evento()
        elif opcion == '10':
            self.aceptar_inscripcion()
        elif opcion == '11':
            self.verificar_inscripcion()

    def ver_datos(self):
        self.ver_usuario()
        self.ver_institucion()
        self.ver_colaborador()
        self.ver_comprometido()
        self.ver_beneficio()
        self.ver_evento()
        self.ver_estudiante()
        self.ver_publicacion()
        self.ver_inscripcion()
        self.ver_aceptacion()
        self.ver_verificacion()

    def ver_usuario(self):
        print("Mostrando datos del usuario")
        # código para mostrar los datos del usuario

    def ver_institucion(self):
        print("Mostrando datos de la institución")
        # código para mostrar los datos de la institución

    def ver_colaborador(self):
        print("Mostrando datos del colaborador")
        # código para mostrar los datos del colaborador

    def ver_comprometido(self):
        print("Mostrando datos del comprometido")
        # código para mostrar los datos del comprometido

    def ver_beneficio(self):
        print("Mostrando datos del beneficio")
        # código para mostrar los datos del beneficio

    def ver_evento(self):
        print("Mostrando datos del evento")
        # código para mostrar los datos del evento

    def ver_estudiante(self):
        print("Mostrando datos del estudiante")
        # código para mostrar los datos del estudiante

    def ver_publicacion(self):
        print("Mostrando datos de la publicación")
        # código para mostrar los datos de la publicación

    def ver_inscripcion(self):
        print("Mostrando datos de la inscripción")
        # código para mostrar los datos de la inscripción

    def ver_aceptacion(self):
        print("Mostrando datos de la aceptación")
        # código para mostrar los datos de la aceptación

    def ver_verificacion(self):
        print("Mostrando datos de la verificación")
        # código para mostrar los datos de la verificación

# Métodos para registrar entidades
    def registrar_usuario(self):
        print("Registrando usuario")
        # código para registrar usuario

    def registrar_institucion(self):
        print("Registrando institución")
        # código para registrar institución

    def registrar_colaborador(self):
        print("Registrando colaborador")
        # código para registrar colaborador

    def registrar_comprometido(self):
        print("Registrando comprometido")
        # código para registrar comprometido

    def registrar_beneficio(self):
        print("Registrando beneficio")
        # código para registrar beneficio

    def registrar_evento(self):
        print("Registrando evento")
        # código para registrar evento

    def registrar_estudiante(self):
        print("Registrando estudiante")
        # código para registrar estudiante

    def publicar_evento(self):
        print("Publicando evento")
        # código para publicar evento

    def inscribir_evento(self):
        print("Inscribiendo evento")
        # código para inscribir evento

    def aceptar_inscripcion(self):
        print("Aceptando inscripción")
        # código para aceptar inscripción

    def verificar_inscripcion(self):
        print("Verificando inscripción")
        # código para verificar inscripción
