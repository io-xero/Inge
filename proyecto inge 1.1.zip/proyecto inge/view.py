# view.py
class View:
    def menu_principal(self):
        print("Menú Principal")
        print("1. Ingresar datos")
        print("2. Consultar todos los datos")
        print("0. Salir")
        return input("Seleccione una opción: ")

    def menu_ingresar_datos(self):
        print("Menú Ingresar Datos")
        print("1. Registrar Usuario")
        print("2. Registrar Institución")
        print("3. Registrar Colaborador")
        print("4. Registrar Comprometido")
        print("5. Registrar Beneficio")
        print("6. Registrar Evento")
        print("7. Registrar Estudiante")
        print("8. Publicar Evento")
        print("9. Inscribir Evento")
        print("10. Aceptar Inscripción")
        print("11. Verificar Inscripción")
        return input("Seleccione una opción: ")

    # Métodos para obtener datos de entrada y mostrar datos (como en la versión anterior)
