# view.py
class View:
    def menu_principal(self):
        print("1. Registrar usuario")
        print("2. Ver usuario")
        print("3. Registrar institución")
        print("4. Ver institución")
        print("5. Registrar colaborador")
        print("6. Ver colaborador")
        print("7. Registrar comprometido")
        print("8. Ver comprometido")
        print("9. Registrar beneficio")
        print("10. Ver beneficio")
        print("11. Registrar evento")
        print("12. Ver evento")
        print("13. Registrar estudiante")
        print("14. Ver estudiante")
        print("15. Publicar evento")
        print("16. Ver publicación")
        print("17. Inscribir evento")
        print("18. Ver inscripción")
        print("19. Aceptar inscripción")
        print("20. Ver aceptación")
        print("21. Verificar inscripción")
        print("22. Ver verificación")
        print("0. Salir")
        return input("Seleccione una opción: ")

    def obtener_datos_usuario(self):
        username = input("Ingrese nombre de usuario: ")
        password = input("Ingrese contraseña: ")
        return username, password

    def mostrar_usuario(self, usuario):
        if usuario:
            print(f"Usuario: {usuario[0]}, Contraseña: {usuario[1]}")
        else:
            print("Usuario no encontrado")

    def obtener_datos_institucion(self):
        name = input("Ingrese nombre de la institución: ")
        address = input("Ingrese dirección: ")
        return name, address

    def mostrar_institucion(self, institucion):
        if institucion:
            print(f"Institución: {institucion[0]}, Dirección: {institucion[1]}")
        else:
            print("Institución no encontrada")

    def obtener_datos_colaborador(self):
        username = input("Ingrese nombre de usuario: ")
        password = input("Ingrese contraseña: ")
        return username, password

    def mostrar_colaborador(self, colaborador):
        if colaborador:
            print(f"Colaborador: {colaborador[0]}, Contraseña: {colaborador[1]}")
        else:
            print("Colaborador no encontrado")

    def obtener_datos_comprometido(self):
        username = input("Ingrese nombre de usuario: ")
        password = input("Ingrese contraseña: ")
        return username, password

    def mostrar_comprometido(self, comprometido):
        if comprometido:
            print(f"Comprometido: {comprometido[0]}, Contraseña: {comprometido[1]}")
        else:
            print("Comprometido no encontrado")

    def obtener_datos_beneficio(self):
        name = input("Ingrese nombre del beneficio: ")
        description = input("Ingrese descripción: ")
        return name, description

    def mostrar_beneficio(self, beneficio):
        if beneficio:
            print(f"Beneficio: {beneficio[0]}, Descripción: {beneficio[1]}")
        else:
            print("Beneficio no encontrado")

    def obtener_datos_evento(self):
        title = input("Ingrese título del evento: ")
        description = input("Ingrese descripción: ")
        date = input("Ingrese fecha (YYYY-MM-DD): ")
        return title, description, date

    def mostrar_evento(self, evento):
        if evento:
            print(f"Evento: {evento[1]}, Descripción: {evento[2]}, Fecha: {evento[3]}")
        else:
            print("Evento no encontrado")

    def obtener_datos_estudiante(self):
        username = input("Ingrese nombre de usuario: ")
        password = input("Ingrese contraseña: ")
        return username, password

    def mostrar_estudiante(self, estudiante):
        if estudiante:
            print(f"Estudiante: {estudiante[0]}, Contraseña: {estudiante[1]}")
        else:
            print("Estudiante no encontrado")

    def obtener_id_evento(self):
        return int(input("Ingrese ID del evento: "))

    def obtener_datos_inscripcion(self):
        event_id = int(input("Ingrese ID del evento: "))
        username = input("Ingrese nombre de usuario: ")
        return event_id, username

    def mostrar_inscripcion(self, inscripcion):
        if inscripcion:
            print(f"Inscripción: Evento ID {inscripcion[0]}, Usuario {inscripcion[1]}")
        else:
            print("Inscripción no encontrada")
