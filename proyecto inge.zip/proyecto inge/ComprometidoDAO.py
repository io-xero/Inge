# ComprometidoDAO.py
import sqlite3

class ComprometidoDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS comprometidos
                               (username TEXT PRIMARY KEY, password TEXT)''')
        self.conn.commit()

    def add_comprometido(self, comprometido_dto):
        self.cursor.execute('INSERT INTO comprometidos (username, password) VALUES (?, ?)', (comprometido_dto.username, comprometido_dto.password))
        self.conn.commit()

    def get_comprometido(self, username):
        self.cursor.execute('SELECT username, password FROM comprometidos WHERE username = ?', (username,))
        return self.cursor.fetchone()
