# PublishEventDAO.py
import sqlite3

class PublishEventDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS published_events
                               (event_id INTEGER PRIMARY KEY)''')
        self.conn.commit()

    def add_published_event(self, publish_event_dto):
        self.cursor.execute('INSERT INTO published_events (event_id) VALUES (?)', (publish_event_dto.event_id,))
        self.conn.commit()

    def get_published_event(self, event_id):
        self.cursor.execute('SELECT event_id FROM published_events WHERE event_id = ?', (event_id,))
        return self.cursor.fetchone()
