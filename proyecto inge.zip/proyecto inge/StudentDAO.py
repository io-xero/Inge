# StudentDAO.py
import sqlite3

class StudentDAO:
    def __init__(self, database):
        self.conn = sqlite3.connect(database)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS students
                               (username TEXT PRIMARY KEY, password TEXT)''')
        self.conn.commit()

    def add_student(self, student_dto):
        self.cursor.execute('INSERT INTO students (username, password) VALUES (?, ?)', (student_dto.username, student_dto.password))
        self.conn.commit()

    def get_student(self, username):
        self.cursor.execute('SELECT username, password FROM students WHERE username = ?', (username,))
        return self.cursor.fetchone()
